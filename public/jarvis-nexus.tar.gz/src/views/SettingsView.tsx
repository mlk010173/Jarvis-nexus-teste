import React, { useState } from 'react';
import {
  Shield,
  Sliders,
  Volume2,
  Smartphone,
  Download,
  Trash2,
  Check,
  Info,
  Lock,
} from 'lucide-react';
import { AutonomyLevel } from '../core/orchestrator/types.ts';
import { MemoryService } from '../core/memory/memory-service.ts';

interface SettingsViewProps {
  autonomyLevel: AutonomyLevel;
  onUpdateAutonomyLevel: (lvl: AutonomyLevel) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  autonomyLevel,
  onUpdateAutonomyLevel,
}) => {
  const [speechRate, setSpeechRate] = useState(1.0);
  const [speechPitch, setSpeechPitch] = useState(1.0);
  const [savedNotice, setSavedNotice] = useState(false);

  const autonomyLevelsInfo: { level: AutonomyLevel; title: string; desc: string }[] = [
    {
      level: 1,
      title: 'Nível 1 — Somente Responder',
      desc: 'O assistente apenas responde dúvidas textuais. Nenhuma ferramenta é executada.',
    },
    {
      level: 2,
      title: 'Nível 2 — Planejar e Sugerir',
      desc: 'Cria planos estruturados, mas toda e qualquer execução exige aprovação manual prévia.',
    },
    {
      level: 3,
      title: 'Nível 3 — Executar Ferramentas Locais',
      desc: 'Executa leituras, avaliações locais e memórias. Ações destrutivas continuam barradas.',
    },
    {
      level: 4,
      title: 'Nível 4 — Executar Fluxos Aprovados (Padrão)',
      desc: 'Executa subagentes em paralelo e fluxos de tarefas acordados. Pede autorização apenas para deleções.',
    },
    {
      level: 5,
      title: 'Nível 5 — Autonomia Total sob Guardrails',
      desc: 'Resolução contínua de objetivos dentro do orçamento de tokens, mantendo bloqueios de injeção e segurança.',
    },
  ];

  const handleReset = () => {
    if (confirm('Tem certeza que deseja resetar as memórias e planos locais?')) {
      MemoryService.clearAll();
      window.location.reload();
    }
  };

  const handleSavePreferences = () => {
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  return (
    <div className="space-y-5 pb-24">
      <div>
        <h1 className="text-xl font-bold text-slate-100">Configurações & Segurança</h1>
        <p className="text-xs text-slate-400 mt-1">
          Ajuste as permissões de autonomia do Superagente, síntese vocal e proteção de dados.
        </p>
      </div>

      {savedNotice && (
        <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>Configurações salvas com sucesso no dispositivo!</span>
        </div>
      )}

      {/* Autonomy Level Control */}
      <div className="holo-card p-4 rounded-2xl space-y-3">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold text-slate-100">Nível de Autonomia do Orquestrador</h2>
        </div>
        <p className="text-[11px] text-slate-400">
          Define até onde os agentes podem progredir sem solicitar sua confirmação visual.
        </p>

        <div className="space-y-2 pt-1">
          {autonomyLevelsInfo.map((item) => {
            const isSelected = autonomyLevel === item.level;

            return (
              <div
                key={item.level}
                onClick={() => onUpdateAutonomyLevel(item.level)}
                className={`p-3 rounded-xl cursor-pointer border transition-all text-xs ${
                  isSelected
                    ? 'holo-card-active border-cyan-400/60'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200">{item.title}</span>
                  <input
                    type="radio"
                    name="autonomy"
                    checked={isSelected}
                    onChange={() => onUpdateAutonomyLevel(item.level)}
                    className="accent-cyan-400"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* GitHub Export & Publication Card */}
      <div className="holo-card p-4 rounded-2xl space-y-3 border border-cyan-500/30">
        <div className="flex items-center gap-2">
          <Download className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold text-slate-100">Publicação no GitHub</h2>
        </div>
        <p className="text-[11px] text-slate-300">
          O repositório Git local já foi inicializado com a branch <code className="text-cyan-400 font-mono">main</code>, <code className="text-cyan-400 font-mono">README.md</code>, licença MIT e políticas de segurança.
        </p>

        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 space-y-1">
          <div className="text-[10px] text-slate-500">// Comandos para enviar ao seu GitHub:</div>
          <div className="text-cyan-300 font-semibold select-all">git remote add origin https://github.com/SEU_USUARIO/jarvis-nexus.git</div>
          <div className="text-cyan-300 font-semibold select-all">git push -u origin main</div>
        </div>

        <a
          href="/jarvis-nexus.tar.gz"
          download="jarvis-nexus.tar.gz"
          className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 hover:brightness-110 transition-all shadow-md"
        >
          <Download className="w-4 h-4" />
          <span>Baixar Pacote Completo do Projeto (.tar.gz)</span>
        </a>
      </div>

      {/* Mobile PWA & Android Guidance */}
      <div className="holo-card p-4 rounded-2xl space-y-3 border border-slate-800">
        <div className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold text-slate-100">Instalação no Android (PWA & Termux)</h2>
        </div>
        <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
          <p>
            O JARVIS NEXUS foi projetado como uma PWA (Progressive Web App) otimizada para toque:
          </p>
          <ul className="list-disc list-inside space-y-1 text-slate-400 pl-1">
            <li>No Chrome do Android, toque no menu de 3 pontinhos e escolha <strong className="text-cyan-300">"Instalar aplicativo"</strong> ou <strong className="text-cyan-300">"Adicionar à tela inicial"</strong>.</li>
            <li>O aplicativo funcionará em tela cheia com ícone próprio e suporte offline via Service Worker.</li>
            <li>Para executar modelos locais com <code className="text-cyan-400 font-mono">llama.cpp</code>, utilize o aplicativo gratuito Termux da F-Droid.</li>
          </ul>
        </div>
      </div>

      {/* Voice Tuning */}
      <div className="holo-card p-4 rounded-2xl space-y-3">
        <div className="flex items-center gap-2">
          <Volume2 className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold text-slate-100">Síntese de Fala (Web Speech API)</h2>
        </div>

        <div className="space-y-3 text-xs">
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-slate-300">Velocidade da Voz: {speechRate.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.4"
              step="0.05"
              value={speechRate}
              onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
              className="w-full accent-cyan-400"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-slate-300">Tom da Voz: {speechPitch.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.8"
              max="1.2"
              step="0.05"
              value={speechPitch}
              onChange={(e) => setSpeechPitch(parseFloat(e.target.value))}
              className="w-full accent-cyan-400"
            />
          </div>
        </div>

        <button
          onClick={handleSavePreferences}
          className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-semibold"
        >
          Salvar Preferências de Voz
        </button>
      </div>

      {/* Danger Zone */}
      <div className="holo-card p-4 rounded-2xl space-y-3 border border-rose-900/40">
        <div className="flex items-center gap-2 text-rose-400">
          <Lock className="w-4 h-4" />
          <h2 className="text-sm font-bold">Privacidade & Limpeza</h2>
        </div>
        <p className="text-[11px] text-slate-400">
          Nenhuma credencial ou memória é enviada para treinamento de terceiros sem permissão.
        </p>

        <button
          onClick={handleReset}
          className="w-full py-2.5 px-4 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 text-xs font-semibold flex items-center justify-center gap-2 transition-all"
        >
          <Trash2 className="w-4 h-4" />
          <span>Apagar Todas as Memórias e Reiniciar</span>
        </button>
      </div>
    </div>
  );
};
