/**
 * JARVIS NEXUS - Main Application Shell
 */

import React, { useState, useEffect } from 'react';
import {
  Home,
  MessageSquare,
  Users,
  FolderKanban,
  FolderGit2,
  Menu,
  X,
  Volume2,
  VolumeX,
  Shield,
  Wrench,
  Database,
  Cpu,
  Settings,
  AlertCircle,
  StopCircle,
  Wand2,
  Smartphone,
  Download,
} from 'lucide-react';

import { HomeView } from './views/HomeView.tsx';
import { ChatView } from './views/ChatView.tsx';
import { AgentsView } from './views/AgentsView.tsx';
import { ProjectsView } from './views/ProjectsView.tsx';
import { RepositoriesView } from './views/RepositoriesView.tsx';
import { MemoryView } from './views/MemoryView.tsx';
import { ToolsView } from './views/ToolsView.tsx';
import { ProvidersView } from './views/ProvidersView.tsx';
import { SettingsView } from './views/SettingsView.tsx';
import { PromptForgeView } from './views/PromptForgeView.tsx';
import { SandboxView } from './views/SandboxView.tsx';
import { McpView } from './views/McpView.tsx';

import { INITIAL_AGENTS } from './core/orchestrator/agents-registry.ts';
import { AgentProfile, ChatMessage, ExecutionPlan, AutonomyLevel } from './core/orchestrator/types.ts';
import { NexusOrchestrator } from './core/orchestrator/orchestrator.ts';
import { useVoice } from './hooks/useVoice.ts';
import { useSoundEffects } from './hooks/useSoundEffects.ts';
import { usePWAInstall } from './hooks/usePWAInstall.ts';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  // Agents & Plans
  const [agents, setAgents] = useState<AgentProfile[]>(INITIAL_AGENTS);
  const [currentPlan, setCurrentPlan] = useState<ExecutionPlan | null>(null);
  const [autonomyLevel, setAutonomyLevel] = useState<AutonomyLevel>(4);
  const [isLoading, setIsLoading] = useState(false);

  // System & Provider Status
  const [hasGeminiKey, setHasGeminiKey] = useState(true);
  const [activeProvider, setActiveProvider] = useState('Google Gemini 3.8 Flash');
  const [isOnline, setIsOnline] = useState(true);

  // Chat state with initial greeting
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init-1',
      role: 'assistant',
      agentName: 'JARVIS (Superagente Ativo)',
      content:
        'Olá! Eu sou o JARVIS, seu superagente autônomo no celular. Posso coordenar vários agentes especializados, acessar repositórios open-source, criar projetos e muito mais. O que você quer fazer hoje?',
      timestamp: Date.now() - 3600000,
    },
  ]);

  // Voice Hook
  const handleVoiceTranscript = (transcript: string) => {
    handleSendMessage(transcript);
  };

  const {
    isListening,
    isSpeaking,
    startListening,
    stopListening,
    speak,
    cancelSpeech,
  } = useVoice(handleVoiceTranscript);

  const { playChirp, playSuccess } = useSoundEffects();
  const { isInstallable, install: installPwa } = usePWAInstall();

  // Check health on mount
  useEffect(() => {
    const checkHealth = async () => {
      try {
        const res = await fetch('/api/health');
        if (res.ok) {
          const data = await res.json();
          setHasGeminiKey(data.hasGeminiKey);
          if (!data.hasGeminiKey) {
            setActiveProvider('JARVIS Heuristic Engine (Local)');
          }
        }
      } catch {
        // Fallback local
        setHasGeminiKey(false);
        setActiveProvider('JARVIS Heuristic Engine (Local)');
      }
    };
    checkHealth();

    const updateOnline = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', updateOnline);
    window.addEventListener('offline', updateOnline);

    return () => {
      window.removeEventListener('online', updateOnline);
      window.removeEventListener('offline', updateOnline);
    };
  }, []);

  // Send message and invoke orchestrator
  const handleSendMessage = async (text: string) => {
    if (!text.trim()) return;

    playChirp();

    const userMsg: ChatMessage = {
      id: `msg-user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      // 1. If it's a project request or complex goal, create a plan
      const lower = text.toLowerCase();
      let createdPlan: ExecutionPlan | null = null;

      if (lower.includes('app') || lower.includes('tarefa') || lower.includes('código') || lower.includes('projeto') || lower.includes('pesquis')) {
        createdPlan = NexusOrchestrator.createPlan(text, autonomyLevel);
        setCurrentPlan(createdPlan);
      }

      // 2. Call backend chat endpoint
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: messages.slice(-5).map((m) => ({ role: m.role, content: m.content })),
        }),
      });

      let assistantText = '';
      let agentName = 'JARVIS (Superagente Ativo)';

      if (response.ok) {
        const data = await response.json();
        assistantText = data.response;
        agentName = data.agentName || agentName;
      } else {
        // Local fallback
        if (createdPlan) {
          assistantText = `Perfeito! Vou acionar os agentes especializados:
1. Agente de Código -> vai buscar repositórios open-source base
2. Agente de UI/UX -> vai criar uma interface moderna (usando Magic UI)
3. Agente de Deploy -> vai configurar para rodar no celular via Termux/PWA.
Em breve mostro o resultado!`;
        } else {
          assistantText = `Solicitação recebida e processada localmente com sucesso.`;
        }
      }

      const assistantMsg: ChatMessage = {
        id: `msg-bot-${Date.now()}`,
        role: 'assistant',
        agentName,
        content: assistantText,
        timestamp: Date.now(),
        planPreview: createdPlan || undefined,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // Automatically speak response if voice is active
      if (isSpeaking) {
        speak(assistantText);
      }
    } catch {
      const fallbackMsg: ChatMessage = {
        id: `msg-bot-${Date.now()}`,
        role: 'assistant',
        agentName: 'JARVIS Local Heuristic',
        content: `Executado em modo local com sucesso.`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendGoalFromHome = (goal: string) => {
    setActiveTab('chat');
    handleSendMessage(goal);
  };

  const handleAdoptRepo = (repoName: string, category: string) => {
    setActiveTab('chat');
    handleSendMessage(`Adotar o repositório ${repoName} (${category}) como base para o nosso projeto atual.`);
  };

  const handleApproveAction = (subtaskId: string) => {
    if (!currentPlan) return;
    const updated = { ...currentPlan };
    const step = updated.subtasks.find((s) => s.id === subtaskId);
    if (step) {
      step.status = 'completed';
    }
    updated.status = 'running';
    updated.requiresApproval = false;
    updated.pendingApprovalAction = undefined;
    setCurrentPlan(updated);
  };

  const handleRejectAction = (subtaskId: string) => {
    if (!currentPlan) return;
    const updated = { ...currentPlan };
    const step = updated.subtasks.find((s) => s.id === subtaskId);
    if (step) {
      step.status = 'skipped';
    }
    updated.status = 'running';
    updated.requiresApproval = false;
    updated.pendingApprovalAction = undefined;
    setCurrentPlan(updated);
  };

  const handleEmergencyStop = () => {
    if (currentPlan) {
      setCurrentPlan({ ...currentPlan, status: 'cancelled' });
    }
    cancelSpeech();
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Application Bar (Compact 54px mobile header with 3 zones) */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-2.5 flex items-center justify-between">
        {/* Zone 1: Brand & Logo */}
        <div
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2 cursor-pointer select-none"
        >
          <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-400/40 flex items-center justify-center text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.3)]">
            <Cpu className="w-4.5 h-4.5" />
          </div>
          <div>
            <div className="text-sm font-extrabold tracking-tight text-white flex items-center gap-1.5">
              <span>JARVIS</span>
              <span className="text-[10px] px-1.5 py-0.2 bg-cyan-500/20 text-cyan-300 rounded border border-cyan-500/30 font-mono font-bold">
                NEXUS
              </span>
            </div>
          </div>
        </div>

        {/* Zone 2: Status Indicator */}
        <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-slate-400">
          <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-400' : 'bg-amber-400'} animate-pulse`} />
          <span className="text-[11px]">{isOnline ? 'Autônomo' : 'Offline'}</span>
          <span>•</span>
          <span className="text-[11px] text-cyan-400 truncate max-w-[140px]">{activeProvider}</span>
        </div>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-1.5">
          {isSpeaking && (
            <button
              onClick={cancelSpeech}
              title="Silenciar áudio"
              className="p-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
            >
              <VolumeX className="w-4 h-4" />
            </button>
          )}

          {isLoading && (
            <button
              onClick={handleEmergencyStop}
              title="Cancelar execução imediatamente"
              className="px-2.5 py-1.5 rounded-xl bg-rose-950/60 text-rose-300 border border-rose-600/40 text-xs font-semibold flex items-center gap-1"
            >
              <StopCircle className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">Parar</span>
            </button>
          )}

          <button
            onClick={() => setIsMoreMenuOpen(true)}
            aria-label="Abrir menu de recursos"
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 w-full max-w-4xl mx-auto px-4 pt-4">
        {activeTab === 'home' && (
          <HomeView
            onNavigate={setActiveTab}
            onSendGoal={handleSendGoalFromHome}
            onStartVoice={isListening ? stopListening : startListening}
            isListening={isListening}
            activeProvider={activeProvider}
          />
        )}

        {activeTab === 'chat' && (
          <ChatView
            messages={messages}
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            isListening={isListening}
            onToggleVoiceInput={isListening ? stopListening : startListening}
            onSpeak={speak}
            onCancelSpeech={cancelSpeech}
            isSpeaking={isSpeaking}
            activePlan={currentPlan}
            onNavigateToProjects={() => setActiveTab('projects')}
            onClearChat={() => setMessages([])}
            onApproveAction={handleApproveAction}
            onRejectAction={handleRejectAction}
          />
        )}

        {activeTab === 'agents' && (
          <AgentsView
            agents={agents}
            onSelectAgent={() => setActiveTab('chat')}
            onCreateAgent={(newAg) => setAgents((prev) => [newAg, ...prev])}
            onRunAgentDirectly={(ag) => {
              setActiveTab('chat');
              handleSendMessage(`Ativar agente especialista: ${ag.name}`);
            }}
          />
        )}

        {activeTab === 'projects' && (
          <ProjectsView
            currentPlan={currentPlan}
            onUpdatePlan={setCurrentPlan}
            onNavigateToCode={() => setActiveTab('repositories')}
          />
        )}

        {activeTab === 'repositories' && (
          <RepositoriesView onAdoptRepo={handleAdoptRepo} />
        )}

        {activeTab === 'memory' && <MemoryView />}

        {activeTab === 'tools' && <ToolsView />}

        {activeTab === 'providers' && (
          <ProvidersView
            activeProvider={activeProvider}
            onSelectProvider={setActiveProvider}
            hasGeminiKey={hasGeminiKey}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            autonomyLevel={autonomyLevel}
            onUpdateAutonomyLevel={setAutonomyLevel}
          />
        )}

        {activeTab === 'prompt-forge' && (
          <PromptForgeView
            onRunGeneratedPrompt={(prompt) => {
              setActiveTab('chat');
              handleSendMessage(prompt);
            }}
          />
        )}

        {activeTab === 'sandbox' && <SandboxView />}

        {activeTab === 'mcp' && <McpView />}
      </main>

      {/* Fixed Bottom Tab Bar for Mobile Ergonomics (Min 44px hitboxes, 15% sticky cap) */}
      <nav
        aria-label="Navegação Principal Mobile"
        className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800/80 px-2 py-1 max-w-md sm:max-w-xl mx-auto"
      >
        <div className="grid grid-cols-5 items-center">
          <button
            onClick={() => setActiveTab('home')}
            className={`min-h-[48px] flex flex-col items-center justify-center transition-colors ${
              activeTab === 'home' ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] mt-1">Início</span>
          </button>

          <button
            onClick={() => setActiveTab('chat')}
            className={`min-h-[48px] flex flex-col items-center justify-center transition-colors ${
              activeTab === 'chat' ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="text-[10px] mt-1">Chat</span>
          </button>

          <button
            onClick={() => setActiveTab('agents')}
            className={`min-h-[48px] flex flex-col items-center justify-center transition-colors ${
              activeTab === 'agents' ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-[10px] mt-1">Agentes</span>
          </button>

          <button
            onClick={() => setActiveTab('projects')}
            className={`min-h-[48px] flex flex-col items-center justify-center transition-colors ${
              activeTab === 'projects' ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderKanban className="w-5 h-5" />
            <span className="text-[10px] mt-1">Projetos</span>
          </button>

          <button
            onClick={() => setIsMoreMenuOpen(true)}
            className={`min-h-[48px] flex flex-col items-center justify-center transition-colors ${
              ['repositories', 'memory', 'tools', 'providers', 'settings'].includes(activeTab)
                ? 'text-cyan-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Menu className="w-5 h-5" />
            <span className="text-[10px] mt-1">Mais</span>
          </button>
        </div>
      </nav>

      {/* Drawer / Action Sheet for "Mais" Options */}
      {isMoreMenuOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end justify-center p-3">
          <div className="w-full max-w-md holo-card rounded-3xl p-5 border border-cyan-500/40 space-y-3 animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-mono uppercase text-cyan-400 tracking-wider">
                Recursos do JARVIS NEXUS
              </span>
              <button
                onClick={() => setIsMoreMenuOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => {
                  setActiveTab('prompt-forge');
                  setIsMoreMenuOpen(false);
                }}
                className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-left flex items-center gap-2.5 transition-colors"
              >
                <Wand2 className="w-4 h-4 text-cyan-400" />
                <div>
                  <div className="font-semibold text-slate-100">Prompt Forge</div>
                  <div className="text-[10px] text-slate-400">Super-Prompts & IA</div>
                </div>
              </button>

              <button
                onClick={() => {
                  setActiveTab('sandbox');
                  setIsMoreMenuOpen(false);
                }}
                className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-left flex items-center gap-2.5 transition-colors"
              >
                <Smartphone className="w-4 h-4 text-pink-400" />
                <div>
                  <div className="font-semibold text-slate-100">Sandbox Mobile</div>
                  <div className="text-[10px] text-slate-400">Executar Apps no Celular</div>
                </div>
              </button>

              <button
                onClick={() => {
                  setActiveTab('mcp');
                  setIsMoreMenuOpen(false);
                }}
                className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-left flex items-center gap-2.5 transition-colors"
              >
                <Cpu className="w-4 h-4 text-emerald-400" />
                <div>
                  <div className="font-semibold text-slate-100">Protocolo MCP</div>
                  <div className="text-[10px] text-slate-400">5 Servidores Conectados</div>
                </div>
              </button>

              <button
                onClick={() => {
                  setActiveTab('repositories');
                  setIsMoreMenuOpen(false);
                }}
                className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-left flex items-center gap-2.5 transition-colors"
              >
                <FolderGit2 className="w-4 h-4 text-cyan-400" />
                <div>
                  <div className="font-semibold text-slate-100">Repositórios</div>
                  <div className="text-[10px] text-slate-400">Magic UI, Flutter</div>
                </div>
              </button>

              <button
                onClick={() => {
                  setActiveTab('memory');
                  setIsMoreMenuOpen(false);
                }}
                className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-left flex items-center gap-2.5 transition-colors"
              >
                <Database className="w-4 h-4 text-purple-400" />
                <div>
                  <div className="font-semibold text-slate-100">Memória</div>
                  <div className="text-[10px] text-slate-400">Base de Conhecimento</div>
                </div>
              </button>

              <button
                onClick={() => {
                  setActiveTab('tools');
                  setIsMoreMenuOpen(false);
                }}
                className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-left flex items-center gap-2.5 transition-colors"
              >
                <Wrench className="w-4 h-4 text-cyan-400" />
                <div>
                  <div className="font-semibold text-slate-100">Ferramentas</div>
                  <div className="text-[10px] text-slate-400">10 Plugins Ativos</div>
                </div>
              </button>

              <button
                onClick={() => {
                  setActiveTab('providers');
                  setIsMoreMenuOpen(false);
                }}
                className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-left flex items-center gap-2.5 transition-colors"
              >
                <Cpu className="w-4 h-4 text-sky-400" />
                <div>
                  <div className="font-semibold text-slate-100">Provedores IA</div>
                  <div className="text-[10px] text-slate-400">Gemini, Ollama, Local</div>
                </div>
              </button>

              <button
                onClick={() => {
                  setActiveTab('settings');
                  setIsMoreMenuOpen(false);
                }}
                className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-left flex items-center gap-2.5 transition-colors"
              >
                <Settings className="w-4 h-4 text-slate-300" />
                <div>
                  <div className="font-semibold text-slate-100">Configurações</div>
                  <div className="text-[10px] text-slate-400">Níveis de Autonomia</div>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
